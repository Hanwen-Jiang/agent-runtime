# Research data retention must be submitted within 10 business days.
# Research Office is responsible for approving research data retention.
# Research data retention requires approved study protocol.
# Records for research data retention must be retained for 17 months.
# Emergency exceptions for research data retention require written approval from the department head.
# Research data retention must be submitted through the research registry.
raise RuntimeError("READ_MUST_NOT_EXECUTE")